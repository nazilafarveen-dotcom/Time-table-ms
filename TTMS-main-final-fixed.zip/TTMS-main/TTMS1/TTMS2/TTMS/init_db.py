#!/usr/bin/env python3
"""Initialize the TTMS database with schema and seed data."""

import psycopg2
import os
import sys
from dotenv import load_dotenv

# Load environment variables from parent directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, '.env'))

DATABASE_URL = os.getenv('DATABASE_URL', 'postgresql://localhost/timetable_db')

# Handle Render's postgres:// format
if DATABASE_URL.startswith('postgres://'):
    DATABASE_URL = DATABASE_URL.replace('postgres://', 'postgresql://', 1)

try:
    print('Connecting to database...')
    conn = psycopg2.connect(DATABASE_URL)
    conn.autocommit = False
    print('✓ Database connected')
    
    # Read schema file
    schema_path = os.path.join(BASE_DIR, 'database', 'schema_postgres.sql')
    with open(schema_path, 'r') as f:
        schema = f.read()
    
    cur = conn.cursor()
    print('Creating tables and inserting seed data...')
    # Execute statements one by one
    statements = schema.split(';')
    for stmt in statements:
        stmt = stmt.strip()
        if stmt:
            try:
                cur.execute(stmt)
            except Exception as e:
                # Some errors are ok (like CONFLICT DO NOTHING)
                if 'CONFLICT' not in str(e):
                    print(f"  Error: {e}")
    
    conn.commit()
    cur.close()
    conn.close()
    print('✓ Schema initialized successfully!')
    print('\nDefault Credentials:')
    print('  Admin:   username=admin, password=admin123')
    print('  Faculty: username=faculty1, password=faculty123')
    print('  Student: username=student1, password=student123')
except Exception as e:
    print(f'✗ Error: {e}')
    sys.exit(1)
