import random

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
PERIODS = [1, 2, 3, 4, 5, 6, 7]


# ✅ FIXED: Slot-based timetable generation (NO EMPTY P7)
def random_tt(subjects, staff_map, rooms):
    tt = []

    # Create subject pool based on weekly hours
    subject_pool = []
    for s in subjects:
        for _ in range(s["weekly_hours"]):
            subject_pool.append(s)

    random.shuffle(subject_pool)
    index = 0

    # Fill ALL slots (every day × every period)
    for day in DAYS:
        for period in PERIODS:

            if index < len(subject_pool):
                s = subject_pool[index]
                index += 1

                staffs = staff_map.get(s["id"], [])

                tt.append({
                    "day": day,
                    "period": period,
                    "subject_id": s["id"],
                    "staff_id": random.choice(staffs) if staffs else None,
                    "classroom_id": random.choice(rooms)
                })

            else:
                # Fill remaining slots as FREE
                tt.append({
                    "day": day,
                    "period": period,
                    "subject_id": None,
                    "staff_id": None,
                    "classroom_id": None
                })

    return tt


# ✅ FINAL: NO genetic algorithm (this was the issue)
def generate_timetable(subjects, staff_map, rooms):
    return random_tt(subjects, staff_map, rooms)
